//function prototypes
void ConfigureUsart1(int baudrate);